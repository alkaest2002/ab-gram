import { defineStore } from 'pinia'

/** Cross-cutting application state. Single state property: `isLoading`. */
export const useAppStore = defineStore('app', {
  state: () => ({
    isLoading: false,
    navItems: [],
  }),

  getters: {
    /** Convenient in templates: `v-if="app.isIdle"` reads better than a negation. */
    isIdle: (state) => !state.isLoading,
  },

  actions: {
    setLoading(value) {
      this.isLoading = Boolean(value)
    },
  },
})
