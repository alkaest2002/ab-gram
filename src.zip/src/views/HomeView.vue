<script setup>
import { RouterLink } from 'vue-router'

import SociogramPreview from '@/components/home/SociogramPreview.vue'
import BaseButton from '@/components/ui/BaseButton.vue'

/**
 * The five readings are the vocabulary of the graph above: each entry reuses the
 * same mark that appears in the sociogram, so the legend isn't decoration
 * but the key to reading the drawing.
 *
 * `tone` chooses the mark's color, `double` adds the tip at the start too,
 * `dashed` dashes it: the same three variables as the drawing.
 */
const readings = [
  {
    kind: 'choice',
    tone: 'accent',
    title: 'Preferenze',
    text: 'Chi indica chi. La freccia parte da chi sceglie e arriva a chi è stato scelto.',
  },
  {
    kind: 'mutual',
    tone: 'glow',
    double: true,
    title: 'Preferenze reciproche',
    text: 'Le coppie che si scelgono a vicenda: il legame più stabile del gruppo.',
  },
  {
    kind: 'reject',
    tone: 'reject',
    dashed: true,
    title: 'Rifiuti',
    text: 'Le preferenze negative: dicono con chi una persona preferirebbe non lavorare.',
  },
  {
    kind: 'reject-mutual',
    tone: 'reject',
    dashed: true,
    double: true,
    title: 'Rifiuti reciproci',
    text: 'Due persone che si escludono a vicenda: la tensione da sciogliere per prima.',
  },
  {
    kind: 'alone',
    tone: 'muted',
    title: 'Isolamento',
    text: 'Chi esprime preferenze senza riceverne. Iris, nel grafo qui sopra.',
  },
]
</script>

<template>
  <div class="page home">

    <section class="hero space-y-5">
      <p class="eyebrow">Sociometria</p>

      <h1 class="hero-title">
        Analizza le <em>dinamiche dei gruppi</em>
      </h1>

      <p class="lede">
        Registra preferenze e rifiuti dei membri di un gruppo: AB-Grid costruisce il sociogramma, calcola gli
        indici sociometrici e prepara il report da stampare.
      </p>
    </section>

    <SociogramPreview />

    <section class="space-y-6">
      <div class="space-y-3">
        <p class="eyebrow">Legenda</p>
        <h2>Cinque letture dello stesso grafo</h2>
        <p class="max-w-[52ch] text-sm">
          Ogni segno del sociogramma è una relazione: questa è la chiave per leggerlo.
        </p>
      </div>

      <ul class="readings">
        <li v-for="reading in readings" :key="reading.kind" class="reading">
          <span class="reading-glyph" :class="`glyph-${reading.tone}`" aria-hidden="true">
            <svg viewBox="0 0 32 32">
              <circle v-if="reading.kind === 'alone'" class="is-dashed" cx="16" cy="16" r="10.5" />
              <template v-else>
                <path :class="{ 'is-dashed': reading.dashed }" d="M5 16h22" />
                <path d="M22 11l5 5-5 5" />
                <path v-if="reading.double" d="M10 11l-5 5 5 5" />
              </template>
            </svg>
          </span>

          <div class="space-y-1.5">
            <h3>{{ reading.title }}</h3>
            <p class="text-sm">{{ reading.text }}</p>
          </div>
        </li>
      </ul>
    </section>

    <section class="band">
      <div class="space-y-2.5">
        <p class="flow">
          <span>Membri</span>
          <span class="flow-sep" aria-hidden="true">→</span>
          <span>Preferenze</span>
          <span class="flow-sep" aria-hidden="true">→</span>
          <span>Report</span>
        </p>
        <p class="max-w-[52ch] text-sm">
          Tre passaggi, nessun account. I dati restano sul tuo dispositivo: il calcolo avviene nel
          browser e nulla viene inviato a un server.
          <RouterLink to="/privacy" class="link">Informativa privacy</RouterLink>
        </p>
      </div>

      <BaseButton to="/app">Apri l'app</BaseButton>

    </section>
  </div>
</template>

<style scoped>
/* The hero borrows the sociogram's lattice — the dotted grid of the sociometric
   matrix — as a faint backdrop, so the opening text and the drawing read as one
   system rather than two stacked blocks. It stays near-invisible: an atmosphere,
   not a pattern to look at. */
.hero {
  position: relative;
  isolation: isolate;
  padding-block: 1.5rem 0.5rem;
}

.hero::before {
  content: '';
  position: absolute;
  inset: 0;
  z-index: -1;
  background-image: radial-gradient(
    color-mix(in oklab, var(--color-accent) 15%, transparent) 1px,
    transparent 1px
  );
  background-size: 26px 26px;
  mask-image: radial-gradient(ellipse 90% 100% at 50% 0%, #000 25%, transparent 78%);
}

.hero::after {
  content: '';
  position: absolute;
  inset: 0;
  z-index: -2;
  background: radial-gradient(
    ellipse 55% 90% at 50% 0%,
    color-mix(in oklab, var(--color-accent-soft) 90%, transparent),
    transparent 72%
  );
}
</style>
