<script setup>
import { RouterLink, RouterView } from 'vue-router'

import PageTransition from '@/components/ui/PageTransition.vue'
import { appRoutes } from '@/router'

const steps = appRoutes.filter((item) => item.meta?.label)
</script>

<template>
  <div class="page">
    <h1>App</h1>
    <p>Area di lavoro del sociogramma, divisa in tre passaggi.</p>

    <!--
      Here we highlight only the exact match: the entry page has `path: ''`,
      so it resolves to `/app` like the parent and RouterLink treats it as active on
      any child route. With the global `is-active` class it stayed lit even on
      Members/Preferences/Report. `is-ancestor` isn't styled: it only serves to get the
      non-exact active class out of the way.
    -->
    <nav class="flex flex-wrap gap-1" aria-label="Passaggi dell'app">
      <RouterLink
        v-for="step in steps"
        :key="step.name"
        :to="{ name: step.name }"
        class="nav-link"
        active-class="is-ancestor"
        exact-active-class="is-active"
      >
        {{ step.meta.label }}
      </RouterLink>
    </nav>

    <RouterView v-slot="{ Component }">
      <PageTransition>
        <component :is="Component" />
      </PageTransition>
    </RouterView>
  </div>
</template>
