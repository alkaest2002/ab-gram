<script setup>
import { useAppStore } from '@/stores/app'

const app = useAppStore()
</script>

<template>
  <section class="card">
    <h2>Genera il report</h2>
    <p>Passaggio 3 di 3. Il calcolo della rete e la sua rappresentazione grafica arriveranno qui.</p>
    <p><span class="tag tag-off">isLoading: {{ app.isLoading }}</span></p>
  </section>
</template>
