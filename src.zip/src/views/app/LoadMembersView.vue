<script setup>
import { useSociogramStore } from '@/stores/sociogram'

// Store connected but still empty: member input will go here.
const sociogram = useSociogramStore()
</script>

<template>
  <section class="card">
    <h2>Carica i membri</h2>
    <p>Passaggio 1 di 3. Il modulo di inserimento dei nomi del gruppo non è ancora attivo.</p>
    <p class="flex gap-2">
      <span class="tag">membersNames: {{ sociogram.membersNames.length }}</span>
      <span class="tag tag-off">membersCount: {{ sociogram.membersCount }}</span>
    </p>
  </section>
</template>
