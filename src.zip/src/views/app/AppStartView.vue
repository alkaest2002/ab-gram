<script setup>
import BaseButton from '@/components/ui/BaseButton.vue'
</script>

<template>
  <section class="card">
    <p class="eyebrow">Punto di partenza</p>
    <h2>Da dove vuoi cominciare?</h2>
    <p>
      Due strade per lo stesso risultato: leggere prima come funziona, oppure entrare subito nel
      primo passaggio.
    </p>

    <div class="flex flex-wrap gap-2 pt-1">
      <BaseButton variant="soft" to="/docs">Leggi la documentazione</BaseButton>
      <BaseButton :to="{ name: 'load-members' }">Inizia dai membri</BaseButton>
    </div>

    <p class="text-sm">
      <span class="tag tag-off">Consiglio</span>
      alla prima volta conviene la documentazione: spiega cosa sono preferenze e report prima di
      chiederli.
    </p>
  </section>
</template>
