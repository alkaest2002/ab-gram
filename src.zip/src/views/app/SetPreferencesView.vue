<template>
  <section class="card">
    <h2>Imposta le preferenze</h2>
    <p>
      Passaggio 2 di 3. Qui ogni membro indicherà le proprie preferenze positive
      (<code>likes</code>) e negative (<code>dislikes</code>).
    </p>
    <p>Nessuna logica di raccolta è ancora collegata.</p>
  </section>
</template>
