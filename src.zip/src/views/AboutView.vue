<template>
  <div class="page">
    <h1>About</h1>
    <p>
      AB-Grid nasce come progetto dimostrativo per mostrare l'analisi delle relazioni in un gruppo
      di lavoro o in una classe.
    </p>

    <section class="card">
      <h2>Il progetto</h2>
      <p>
        Testo segnaposto: qui trovano posto la presentazione del gruppo di lavoro e il contesto in
        cui lo strumento viene usato.
      </p>
    </section>

    <section class="card">
      <h2>Contatti</h2>
      <p>Scrivi a <a href="mailto:info@ab-grid.example">info@ab-grid.example</a>.</p>
    </section>
  </div>
</template>
