<script setup>
import { RouterView } from 'vue-router'

import AppFooter from '@/components/layout/AppFooter.vue'
import AppHeader from '@/components/layout/AppHeader.vue'
import PageTransition from '@/components/ui/PageTransition.vue'
import { useAppStore } from '@/stores/app'

const app = useAppStore()
</script>

<template>
  <!-- min-h-dvh + flex-1 on main: every page covers the viewport and overflows when needed. -->
  <div class="flex min-h-dvh flex-col">
    <div
      v-if="app.isLoading"
      class="fixed inset-x-0 top-0 z-20 h-0.5 animate-pulse bg-linear-to-r from-accent to-glow"
      role="status"
      aria-label="Caricamento in corso"
    />

    <AppHeader />

    <main class="flex-1">
      <RouterView v-slot="{ Component }">
        <PageTransition>
          <component :is="Component" />
        </PageTransition>
      </RouterView>
    </main>

    <AppFooter />
  </div>
</template>
